19.10.2026 ♡ — Little Anniversary World

HOW TO PREVIEW
1. Extract this ZIP.
2. Open index.html in a browser.

HOW TO PUBLISH FREE WITH GITHUB PAGES
1. On GitHub, create a NEW PUBLIC repository named anniversary-world (or any name).
2. Upload index.html, the assets folder, and this README.txt. Upload the folder contents, not the ZIP itself.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select Branch: main and folder: /(root), then Save.
6. Wait a minute or two. The Pages section will show the live website URL.

IMPORTANT PRIVACY NOTE
GitHub Pages websites in public repositories are public on the internet. The photos in this bundle will be visible to anyone who has the link (and potentially discoverable). Only publish photos you are comfortable sharing publicly. If you want the site to be private, do not publish it using a public GitHub Pages repository.

This is a static HTML/CSS/JavaScript site. No paid service or API key is required. Background music starts only when tapped. Character speech uses the browser's Turkish text-to-speech voice if available.
